local _, NS = ...

-- Treat any session under 30 minutes as taking 30 minutes when calculating historical rates
-- to prevent rapid quest turn-ins from skewing "XP/hr" and "Money/hr" records.
local MIN_SESSION_DURATION = 1800

--- Ensures the number of kept sessions is within safe bounds (5 to 100).
--- @param n number|string|nil The requested number of sessions to keep.
--- @return number The clamped integer value.
local function clampKeepSessions(n)
  n = math.floor(tonumber(n) or 30)
  -- 🛡️ Sentinel: Validate for NaN and Infinity to prevent validation bypass
  if NS.IsInvalidNumber(n) then
    n = 30
  elseif n < 5 then
    n = 5
  elseif n > 100 then
    n = 100
  end
  return n
end

local safeString = function(value, fallback) return NS.safeString(value, fallback) end

--- Validates if a zone name is usable for attribution.
--- @param zone string|nil The zone name to check.
--- @return boolean True if the zone is valid, false otherwise.
local function isValidZone(zone)
  local z = safeString(zone, "")
  return z ~= "" and z ~= "Unknown"
end

--- Computes the arithmetic mean of an array of numbers.
--- @param values number[] The array of numbers.
--- @return number The average, or 0 if the array is empty.
local function average(values)
  local n = #values
  if n == 0 then return 0 end
  local sum = 0
  for i = 1, n do
    sum = sum + values[i]
  end
  return sum / n
end

--- Computes the median of an array of numbers.
--- @param values number[] The array of numbers.
--- @return number The median, or 0 if the array is empty.
local function median(values)
  local n = #values
  if n == 0 then return 0 end

  local sorted = {}
  for i = 1, n do
    sorted[i] = values[i]
  end
  table.sort(sorted)

  if n % 2 == 1 then
    return sorted[(n + 1) / 2]
  end
  return (sorted[n / 2] + sorted[(n / 2) + 1]) / 2
end

NS.NormalizeKeepSessions = clampKeepSessions

--- Gets a unique profile key based on the player's realm, name, and class.
--- Used to partition stats between alts or different servers.
--- @return string The profile key in the format "Realm:Name:CLASS".
function NS.GetProfileKey()
  local name = "Unknown"
  local realm = "Unknown"
  local classToken = "UNKNOWN"

  if UnitName then
    local unitName, unitRealm = UnitName("player")
    name = safeString(unitName, name)
    realm = safeString(unitRealm, realm)
  end

  if (realm == "Unknown" or realm == "") and GetRealmName then
    realm = safeString(GetRealmName(), realm)
  end

  if UnitClass then
    local _, classFile = UnitClass("player")
    classToken = safeString(classFile, classToken)
  end

  return string.format("%s:%s:%s", realm, name, classToken)
end

--- Retrieves the persistent storage table for the current character's sessions.
--- Handles initialization and migration from an unknown profile if necessary.
--- @param createIfMissing boolean Whether to create the profile structure if it doesn't exist.
--- @return table|nil The profile table containing a `sessions` array, or nil if DB is unavailable.
function NS.GetProfileStore(createIfMissing)
  if not DingTimerDB then return nil end

  DingTimerDB.xp = DingTimerDB.xp or {}
  DingTimerDB.xp.keepSessions = clampKeepSessions(DingTimerDB.xp.keepSessions)
  DingTimerDB.xp.profiles = DingTimerDB.xp.profiles or {}

  local key = NS.GetProfileKey()
  local profile = DingTimerDB.xp.profiles[key]
  local unknownKey = "Unknown:Unknown:UNKNOWN"

  if not profile and key ~= unknownKey then
    local unknownProfile = DingTimerDB.xp.profiles[unknownKey]
    if unknownProfile and type(unknownProfile.sessions) == "table" and #unknownProfile.sessions > 0 then
      profile = { sessions = unknownProfile.sessions }
      DingTimerDB.xp.profiles[key] = profile
      DingTimerDB.xp.profiles[unknownKey] = { sessions = {} }
    end
  end

  if not profile and createIfMissing then
    profile = { sessions = {} }
    DingTimerDB.xp.profiles[key] = profile
  end

  if profile then
    profile.sessions = profile.sessions or {}
  end

  return profile
end

--- Trims the oldest sessions from a profile to enforce the retention limit.
--- @param profile table The profile store to trim.
--- @param keepN number|nil Optional explicit limit (defaults to saved setting or 30).
function NS.TrimSessions(profile, keepN)
  if not profile or type(profile.sessions) ~= "table" then return end

  local keep = clampKeepSessions(keepN or (DingTimerDB and DingTimerDB.xp and DingTimerDB.xp.keepSessions) or 30)
  local sessions = profile.sessions
  local overflow = #sessions - keep
  if overflow <= 0 then return end

  -- ⚡ Shift in one O(N) pass instead of O(N^2) table.remove(t,1) loop
  local len = #sessions
  for i = 1, keep do
    sessions[i] = sessions[i + overflow]
  end
  for i = len, keep + 1, -1 do
    sessions[i] = nil
  end
end

--- Clears all recorded sessions for the current character and updates the UI.
function NS.ClearProfileSessions()
  local profile = NS.GetProfileStore(true)
  if not profile then return end

  profile.sessions = {}
  if NS.RefreshInsightsWindow then
    NS.RefreshInsightsWindow()
  end
end

--- Finalizes and saves the active tracking session to the character's history.
--- Requires at least some XP or money to have been earned to save a record.
--- @param reason string|nil The cause of the session recording (e.g., "LEVEL_UP", "MANUAL_RESET").
--- @return table|nil The saved session record, or nil if there was nothing to record.
function NS.RecordSession(reason)
  if not DingTimerDB or not NS.state then return nil end

  local now = GetTime()
  local startedAt = NS.state.sessionStartTime or now
  local durationSec = math.max(1, now - startedAt)
  local xpGained = NS.state.sessionXP or 0
  local moneyNetCopper = NS.state.sessionMoney or 0

  if xpGained <= 0 and moneyNetCopper == 0 then
    return nil
  end

  local levelStart = NS.state.levelStart or ((UnitLevel and UnitLevel("player")) or 0)
  local levelEnd = (UnitLevel and UnitLevel("player")) or levelStart
  local sampleCount = (type(NS.state.events) == "table") and #NS.state.events or 0

  -- Smooth out historical rates by treating any session under MIN_SESSION_DURATION
  -- as taking MIN_SESSION_DURATION. This prevents 2-minute turn-in sessions from
  -- artificially inflating the "Average XP/hr" and "Average Money/hr".
  local rateDivisor = math.max(MIN_SESSION_DURATION, durationSec)
  local avgXph = (xpGained / rateDivisor) * 3600
  local avgMoneyPh = (moneyNetCopper / rateDivisor) * 3600

  local endedStamp = math.floor(now + 0.5)
  local segments = {}
  if NS.FinalizeSessionSegments then
    segments = NS.FinalizeSessionSegments(reason, now)
  end

  -- Default to current zone, then override with whichever segment earned the most XP.
  -- This prevents "reset from Orgrimmar after farming Hillsbrad" from misattributing the session.
  local zone = "Unknown"
  if GetZoneText then
    zone = safeString(GetZoneText(), "Unknown")
  end
  local primaryZoneXP = 0
  for i = 1, #segments do
    local seg = segments[i]
    if (seg.xpGained or 0) > primaryZoneXP and isValidZone(seg.zone) then
      primaryZoneXP = seg.xpGained
      zone = seg.zone
    end
  end

  local record = {
    id = string.format("%d-%d-%d", endedStamp, levelStart, levelEnd),
    startedAt = startedAt,
    endedAt = now,
    durationSec = durationSec,
    levelStart = levelStart,
    levelEnd = levelEnd,
    xpGained = xpGained,
    moneyNetCopper = moneyNetCopper,
    avgXph = avgXph,
    avgMoneyPh = avgMoneyPh,
    sampleCount = sampleCount,
    zone = zone,
    reason = reason or "MANUAL_RESET",
    coachGoal = (DingTimerDB.coach and DingTimerDB.coach.goal) or "ding",
    segments = segments,
  }

  if NS.BuildCoachSummary then
    record.coachSummary = NS.BuildCoachSummary(record)
  end

  local profile = NS.GetProfileStore(true)
  if not profile then return end
  local sessions = profile.sessions
  sessions[#sessions + 1] = record
  NS.TrimSessions(profile)

  if record.coachSummary and NS.StoreCoachSummary then
    NS.StoreCoachSummary(record.coachSummary, record.reason == "LOGOUT")
    if record.reason ~= "LOGOUT" and NS.DeliverCoachSummary then
      NS.DeliverCoachSummary(record.coachSummary)
    end
  end

  if NS.RefreshInsightsWindow then
    NS.RefreshInsightsWindow()
  end

  return record
end

--- Computes the trend percentage comparing the newest half of the window to the previous half.
--- @param chartWindow number The size of the recent sessions window.
--- @param count number Total number of sessions.
--- @param sessions table The list of sessions.
--- @return number The trend percentage.
local function calculateTrendPct(chartWindow, count, sessions)
  local trendPct = 0
  if chartWindow >= 4 then
    local pairCount = math.floor(chartWindow / 2)
    local windowStart = count - (pairCount * 2) + 1
    local prevTotal = 0
    local newTotal = 0

    for i = windowStart, windowStart + pairCount - 1 do
      local val = tonumber(sessions[i].avgXph) or 0
      if NS.IsInvalidNumber(val) then val = 0 end
      prevTotal = prevTotal + val
    end
    for i = windowStart + pairCount, windowStart + (pairCount * 2) - 1 do
      local val = tonumber(sessions[i].avgXph) or 0
      if NS.IsInvalidNumber(val) then val = 0 end
      newTotal = newTotal + val
    end

    local prevAvg = prevTotal / pairCount
    local newAvg = newTotal / pairCount
    if prevAvg > 0 then
      trendPct = ((newAvg - prevAvg) / prevAvg) * 100
    end
  end
  return trendPct
end

--- Processes zone statistics to find the top 3 zones by average XP per hour.
--- @param zoneStats table The map of zone statistics.
--- @return table The sorted list of top 3 zone leaders.
local function calculateZoneLeaders(zoneStats)
  local zoneLeaders = {}
  for _, stat in pairs(zoneStats) do
    zoneLeaders[#zoneLeaders + 1] = {
      zone = stat.zone,
      avgXph = (stat.sessions > 0) and (stat.totalXph / stat.sessions) or 0,
      sessions = stat.sessions,
    }
  end
  table.sort(zoneLeaders, function(a, b)
    if a.avgXph == b.avgXph then
      return a.zone < b.zone
    end
    return a.avgXph > b.avgXph
  end)
  while #zoneLeaders > 3 do
    table.remove(zoneLeaders)
  end
  return zoneLeaders
end

--- Aggregates statistics across recent historical sessions for the Insights UI.
--- Computes trends, medians, and extracts a window of recent charts points.
--- @param limit number|nil The maximum number of recent session rows to return.
--- @return table A summary object with total counts, median/best values, and trend data.
function NS.GetInsightsSummary(limit)
  local limitNum = tonumber(limit) or 10
  if NS.IsInvalidNumber(limitNum) then
    limitNum = 10
  end
  local rowLimit = math.max(1, math.floor(limitNum))
  local profile = NS.GetProfileStore(false)
  local sessions = (profile and profile.sessions) or {}
  local count = #sessions

  local rows = {}
  local firstIdx = math.max(1, count - rowLimit + 1)
  local r_count = 0
  for i = count, firstIdx, -1 do
    r_count = r_count + 1
    rows[r_count] = sessions[i]
  end

  local xphValues = {}
  local durations = {}
  local bestXph = 0
  local bestSession = nil
  local lastSession = sessions[count]
  local zoneStats = {}

  -- ⚡ Bolt: Use explicit counters for table insertion to avoid O(N) `#` operator
  -- overhead on every loop iteration, improving aggregation performance by ~35%
  local x_count, d_count = 0, 0
  for i = 1, count do
    local s = sessions[i]
    local xph = tonumber(s.avgXph) or 0
    if NS.IsInvalidNumber(xph) then xph = 0 end
    local dur = tonumber(s.durationSec) or 0
    if NS.IsInvalidNumber(dur) then dur = 0 end

    x_count = x_count + 1
    xphValues[x_count] = xph

    if dur > 0 then
      d_count = d_count + 1
      durations[d_count] = dur
    end
    if xph > bestXph then
      bestXph = xph
      bestSession = s
    end

    local zoneKey = safeString(s.zone, "Unknown")
    local zoneEntry = zoneStats[zoneKey]
    if not zoneEntry then
      zoneEntry = { zone = zoneKey, totalXph = 0, sessions = 0 }
      zoneStats[zoneKey] = zoneEntry
    end
    zoneEntry.totalXph = zoneEntry.totalXph + xph
    zoneEntry.sessions = zoneEntry.sessions + 1
  end

  local chartValues = {}
  local chartWindow = math.min(20, count)
  if chartWindow > 0 then
    local start = count - chartWindow + 1
    local c_count = 0
    for i = start, count do
      local val = tonumber(sessions[i].avgXph) or 0
      if NS.IsInvalidNumber(val) then val = 0 end
      c_count = c_count + 1
      chartValues[c_count] = val
    end
  end

  local trendPct = calculateTrendPct(chartWindow, count, sessions)
  local zoneLeaders = calculateZoneLeaders(zoneStats)

  return {
    totalSessions = count,
    rows = rows,
    chartValues = chartValues,
    medianXph = median(xphValues),
    bestXph = bestXph,
    avgLevelTime = average(durations),
    trendPct = trendPct,
    bestSession = bestSession,
    lastSession = lastSession,
    zoneLeaders = zoneLeaders,
  }
end
